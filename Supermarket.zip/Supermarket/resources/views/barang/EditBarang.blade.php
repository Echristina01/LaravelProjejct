@extends('layouts.app')
@section('content')

    <div class="container" style="margin-top: 50px; margin-bottom: 50px">
        <div class="row">
            <h1 class="col">Edit Barang</h1>
        </div>
        <div class="row">
            <div class="col">
                <form action="{{ route('barang.update', $barang) }}" method="post">
                    @csrf
                    <input type="hidden" name="_method" value="PATCH">
                    <div class="form-group">
                        <label>Nama Barang:</label>
                        <input type="text" class="form-control" name="nama"value="{{ $barang->nama }}" onmouseover="this.style.boxShadow='0px 0px 15px Grey'" onmouseout="this.style.boxShadow='0px 0px 0px Grey'">
                    </div>
                    <div class="form-group">
                        <label>Kode Barang:</label>
                        <input class="form-control" name="kode" value="{{ $barang->kode }}" onmouseover="this.style.boxShadow='0px 0px 15px Grey'" onmouseout="this.style.boxShadow='0px 0px 0px Grey'">
                    </div>
                    <div class="form-group">
                        <label>Harga:</label>
                        <input class="form-control" name="harga" value="{{ $barang->harga }}" onmouseover="this.style.boxShadow='0px 0px 15px Grey'" onmouseout="this.style.boxShadow='0px 0px 0px Grey'">
                    </div>
                    <div class="form-group">
                            @foreach ($kategoris as $kategori)
                            @if ($kategori->kebersihan == $barang->kode) {
                                <option value="{{ $barang->kode }}" selected>{{$kategori->kebersihan}}</option>
                            }
                            @else{
                                ($kategori->atk == $barang->kode) {
                                    <option value="{{ $barang->kode }}" selected>{{$kategori->atk}}</option>
                            }
                            @else{
                                ($kategori->obat == $barang->kode) {
                                    <option value="{{ $barang->kode}}" selected>{{$kategori->obat}}</option>
                            } 
                            @else{
                                ($kategori->dapur == $barang->kode) {
                                    <option value="{{ $barang->kode}}" selected>{{$kategori->dapur}}</option>
                            }      
                            @else{
                                ($kategori->fnb == $barang->kode) {
                                    <option value="{{ $barang->kode }}" selected>{{$kategori->fnb}}</option>
                            }
                            @endif
                            @endforeach
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection
