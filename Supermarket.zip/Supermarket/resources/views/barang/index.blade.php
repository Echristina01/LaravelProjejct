@extends('layouts.app')
@section('content')

    <div class="container" style="margin-top: 50px; margin-bottom: 50px">
        <div class="row">
            <h1 class="col">List Barang</h1>
        </div>
        <div class="row">
            <div class="col-md-2 offset-md-10">
            <a href="{{ route('barang.create') }}" class="btn btn-primary btn-block" role="button"
                   aria-pressed="true" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">Tambah Barang</a>
            </div>
        </div>
        <div class="row" style="margin-top: 30px;">
            <table class="table table-striped">
                <thead>
                <tr style="background-color: rgba(255, 236, 236, 0.884)">
                    <th scope="col">Nama Barang</th>
                    <th scope="col">Kode Barang</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Update At</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>

                @foreach($barangs as $barang)
                    <tr style="background-color: rgba(247, 201, 201, 0.849)">
                    <td><a href="{{ route('barang.edit', $barang) }}" onmouseover="this.style.textShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.textShadow='0px 0px 0px LightSkyBlue'">{{ $barang->nama }}</a></td>
                        <td>{{ $barang->kode }}</td>
                        {{-- <td>{{ $barang->role }}</td> --}}
                        @foreach ($barangs as $barang)
                            @if ($barang->nama == $barang->kode)
                                <td>{{ $kategori->$barang }}</td>
                            @endif
                        @endforeach
                        <td>{{ $barang->updated_at}}</td>
                        <td>{{ $barang->created_at}}</td>
                        <td>
                            <form action="{{ route('barang.destroy', $barang) }}" method="post" onsubmit="return confirm('Delete the data?')">
                                @csrf
                                <input type="hidden" name="_method" value="DELETE">
                                <button type="submit" class="btn btn-danger" onmouseover="this.style.boxShadow='0px 0px 15px LightBlue'" onmouseout="this.style.boxShadow='0px 0px 0px HotPink'">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
